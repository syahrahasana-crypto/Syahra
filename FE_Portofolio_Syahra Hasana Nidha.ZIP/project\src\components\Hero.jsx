import React from 'react';
import { Github, Linkedin, Mail, FileText, Phone } from 'lucide-react';

const Hero = () => {
  return (
    <section id="about" className="pt-24 pb-12 md:pt-32 md:pb-24 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 text-center md:text-left mb-8 md:mb-0">
          <h2 className="text-blue-500 font-semibold tracking-wide uppercase">Halo, Saya</h2>
          <h1 className="mt-2 text-4xl md:text-6xl font-bold text-white tracking-tight">
            Syahra Hasana Nidha
          </h1>
          <p className="mt-4 text-xl text-gray-400 max-w-lg mx-auto md:mx-0">
            Mahasiswa Program Studi Sistem Informasi Universitas Sriwijaya.
          </p>
          
          <div className="mt-8 flex justify-center md:justify-start space-x-4">
            <a href="mailto:nidhasyahra@gmail.com" className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
              Hubungi Saya
            </a>
            <a href="#" className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:border-gray-400 hover:text-white transition-colors font-medium flex items-center gap-2">
              <FileText size={20} /> CV
            </a>
          </div>

          <div className="mt-8 flex justify-center md:justify-start space-x-6 text-gray-400">
            <a href="https://linkedin.com/in/syahra-hasana-nidha" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 transition-colors"><Linkedin size={24} /></a>
            <a href="mailto:nidhasyahra@gmail.com" className="hover:text-blue-500 transition-colors"><Mail size={24} /></a>
            <a href="https://wa.me/6285273748711" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 transition-colors"><Phone size={24} /></a>
          </div>
        </div>
        
        <div className="md:w-1/2 flex justify-center">
          <div className="relative w-64 h-80 md:w-80 md:h-96 rounded-2xl overflow-hidden border-4 border-blue-500 shadow-2xl shadow-blue-500/20 rotate-3 hover:rotate-0 transition-transform duration-500">
            {/* Profile Image */}
            <img 
              src="/profile.jpg" 
              alt="Profile" 
              className="w-full h-full object-cover object-center bg-slate-800"
            />
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
         <div className="bg-slate-800/50 p-8 rounded-2xl border border-slate-700">
            <h3 className="text-2xl font-bold text-white mb-4">About Me</h3>
            <p className="text-gray-400 leading-relaxed">
              Mahasiswa Program Studi Sistem Informasi Universitas Sriwijaya yang memiliki ketertarikan tinggi pada bidang teknologi dan analisis sistem. 
              Memiliki semangat untuk mempelajari hal baru, menyukai pekerjaan berbasis analisis dan pemrograman, serta berkomitmen untuk terus berkembang 
              dan memberikan kontribusi yang bermanfaat. Terbiasa bekerja secara mandiri maupun dalam tim, bertanggung jawab, dan mampu mengelola waktu dengan baik.
            </p>
         </div>
      </div>
    </section>
  );
};

export default Hero;
