import React from 'react';
import { Trophy, Star } from 'lucide-react';

const data = [
  {
    id: 1,
    title: 'Juara 3 Fotografi',
    description:
      'Meraih juara 3 dalam bidang fotografi di event sekolah pada tahun 2024.',
    img: '/juara-fotografi.png',
  },
  {
    id: 2,
    title: 'Workshop SINERGI FEST',
    description:
      'Menjadi peserta aktif dalam event workshop SINERGI FEST dan berhasil menyelesaikan proyek web freelancer pada tahun 2025.',
    img: '/workshop-sinergi.png',
  },
];

export default function Achievements() {
  return (
    <section id="achievements" className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-serif font-semibold mb-8">Achievement</h2>

        <div className="grid md:grid-cols-2 gap-8">
          {data.map((item) => (
            <article key={item.id} className="flex items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-900/40 to-slate-800 flex-shrink-0 flex items-center justify-center border-4 border-indigo-600 shadow-xl">
                {item.id === 1 ? (
                  <Trophy className="w-20 h-26 text-yellow-400 drop-shadow-lg" aria-label="Piala" />
                ) : (
                  <Star className="w-20 h-26 text-yellow-400 drop-shadow-lg" aria-label="Bintang" />
                )}
              </div>

              <div>
                <h3 className="text-xl font-semibold text-indigo-200">{item.title}</h3>
                <p className="text-sm text-gray-300 mt-2">{item.description}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
