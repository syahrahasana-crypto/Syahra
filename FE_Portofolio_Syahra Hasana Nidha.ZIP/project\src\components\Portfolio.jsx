import React from 'react';
import { ExternalLink, Github } from 'lucide-react';

const Portfolio = () => {
  const projects = [
    {
      title: "Freelance Finder Website",
      description: "Platform pencarian kerja freelance yang dibangun saat Workshop SINERGI FEST. Membantu freelancer menemukan pekerjaan yang sesuai.",
      tags: ["React", "Web Development", "UI/UX"],
      image: "/freelance-finder-view.png",
      demoLink: "/PROJECT1/index.html",
      repoLink: "#"
    },
    {
      title: "Harmoni Nusantara",
      description: "Program Kerja Kresbud yang meliputi event Fashion Show, Memasak, dan Pameran Budaya untuk melestarikan budaya nusantara.",
      tags: ["Event Organizer", "Teamwork", "Culture"],
      image: "/wall-magazine.png",
      demoLink: "#",
      repoLink: "#"
    },
    {
      title: "Wall Magazine",
      description: "Desain majalah dinding kreatif bertema Food Fight Future. Menampilkan kreativitas dalam visualisasi ide dan pesan.",
      tags: ["Design", "Creative", "Art"],
      image: "/harmoni-nusantara.png",
      demoLink: "#",
      repoLink: "#"
    }
  ];

  return (
    <section id="portfolio" className="py-20 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Portfolio</h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto mt-4 rounded-full"></div>
          <p className="mt-4 text-gray-400">Beberapa proyek pilihan yang pernah saya kerjakan.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="bg-slate-900 rounded-xl overflow-hidden border border-slate-700 hover:border-blue-500 transition-all hover:shadow-xl hover:-translate-y-1 group">
              <div className="h-48 overflow-hidden relative">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                  <a href={project.demoLink} className="p-2 bg-white rounded-full text-slate-900 hover:bg-blue-500 hover:text-white transition-colors" title="View Demo">
                    <ExternalLink size={20} />
                  </a>
                  <a href={project.repoLink} className="p-2 bg-white rounded-full text-slate-900 hover:bg-blue-500 hover:text-white transition-colors" title="View Code">
                    <Github size={20} />
                  </a>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span key={tagIndex} className="px-3 py-1 bg-slate-800 text-blue-400 text-xs rounded-full border border-slate-700">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
