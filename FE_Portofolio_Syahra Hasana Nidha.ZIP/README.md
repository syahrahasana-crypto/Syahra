# Soal 2: Studi Kasus I — Pengumpulan

Isi folder ini:

- `github.txt` — (harus berisi) URL repository publik GitHub yang memuat solusi.
- `deployment.txt` — (opsional) URL deployment (Netlify/Vercel/GitHub Pages, dsb.) jika ada.
- `README.md` — file ini, berisi cara menjalankan solusi.
- `project/` — salinan proyek frontend (tanpa `node_modules`).
- file kredensial (jika ada) — jika Anda punya file yang biasanya di-gitignore (mis. `.env`), letakkan file tersebut di folder ini.

Cara menjalankan (lokal):

1. Masuk folder `project`:

```bash
cd Soal2_StudiKasusI/project
```

2. Install dependency dan jalankan dev server:

```bash
npm install
npm run dev
```

3. Buka browser ke alamat yang ditampilkan oleh Vite (mis. `http://localhost:5173/`).

Catatan:
- Proyek ini adalah **frontend-only** (React + Vite + Tailwind). Tidak ada backend yang disertakan.
- Jika Anda memiliki file `.env` atau kredensial lain yang biasanya di-ignore, tempatkan file tersebut di folder `Soal2_StudiKasusI` sebelum mengarsipkan.
