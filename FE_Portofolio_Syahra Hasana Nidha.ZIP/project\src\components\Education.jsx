import React from 'react';
import { GraduationCap, Calendar } from 'lucide-react';

const Education = () => {
  const educations = [
    {
      school: "Universitas Sriwijaya",
      degree: "S1 Sistem Informasi",
      year: "2025 - Sekarang",
      description: "Mahasiswa aktif Program Studi Sistem Informasi."
    },
    {
      school: "SMA IT IZZUDDIN",
      degree: "Jurusan Ilmu Pengetahuan Alam",
      year: "2022 - 2025",
      description: "Sebagai alumni yang aktif dalam organisasi sekolah dan kegiatan ekstrakurikuler."
    }
  ];

  return (
    <section id="education" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Education</h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="max-w-3xl mx-auto space-y-8">
          {educations.map((edu, index) => (
            <div key={index} className="bg-slate-800 p-6 rounded-xl border border-slate-700 flex flex-col md:flex-row gap-6 hover:border-blue-500 transition-colors">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-500">
                  <GraduationCap size={32} />
                </div>
              </div>
              <div className="flex-grow">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-xl font-bold text-white">{edu.school}</h3>
                  <div className="flex items-center gap-2 text-blue-400 text-sm mt-1 md:mt-0">
                    <Calendar size={16} />
                    <span>{edu.year}</span>
                  </div>
                </div>
                <h4 className="text-lg font-medium text-gray-300 mb-2">{edu.degree}</h4>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {edu.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Education;
