import React from 'react';
import { Code, Layout, Users, Brain, Clock, Camera, Edit, MessageSquare, Heart, CheckCircle, Video, Music } from 'lucide-react';

const Skills = () => {
  const hardSkills = [
    { name: "Photo/Video Editing", icon: <Video />, level: "Basic" },
    { name: "Design Canva", icon: <Edit />, level: "Basic" },
    { name: "Photography", icon: <Camera />, level: "Basic" },
    { name: "English Communication", icon: <MessageSquare />, level: "Intermediate" },
    { name: "Coding (C++)", icon: <Code />, level: "Basic" },
    { name: "Music (Guitar)", icon: <Music />, level: "Basic" },
  ];

  const softSkills = [
    { name: "Time Management", icon: <Clock /> },
    { name: "Team-work", icon: <Users /> },
    { name: "Critical Thinking", icon: <Brain /> },
    { name: "Problem Solving", icon: <CheckCircle /> },
    { name: "Patience", icon: <Heart /> },
    { name: "Reliable", icon: <CheckCircle /> },
  ];

  return (
    <section id="skills" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Skills</h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-300 mb-8 text-center md:text-left">Hard Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {hardSkills.map((skill, index) => (
              <div key={index} className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-blue-500 transition-colors flex flex-col items-center text-center">
                <div className="text-blue-500 mb-4 p-3 bg-slate-900 rounded-full">
                  {skill.icon}
                </div>
                <h4 className="text-lg font-semibold text-white">{skill.name}</h4>
                <p className="text-sm text-gray-400 mt-1">{skill.level}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-bold text-gray-300 mb-8 text-center md:text-left">Soft Skills</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
             {softSkills.map((skill, index) => (
              <div key={index} className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 flex items-center gap-3">
                <div className="text-green-500">
                  {skill.icon}
                </div>
                <h4 className="text-base font-medium text-white">{skill.name}</h4>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
