import React from 'react';
import { Github, Linkedin, Mail, Heart, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-950 py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <span className="text-2xl font-bold text-white">Syahra Hasana Nidha</span>
            <p className="text-gray-500 text-sm mt-2">Building digital experiences that matter.</p>
          </div>
          
          <div className="flex space-x-6">
            <a href="https://linkedin.com/in/syahra-hasana-nidha" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="mailto:nidhasyahra@gmail.com" className="text-gray-400 hover:text-white transition-colors">
              <Mail size={24} />
            </a>
            <a href="https://wa.me/6285273748711" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
               <Phone size={24} />
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-slate-900 text-center text-gray-600 text-sm flex items-center justify-center gap-1">
          <p>© {new Date().getFullYear()} Portofolio Syahra Hasana Nidha. </p>
          <Heart size={14} className="text-red-500 fill-current" />
        </div>
      </div>
    </footer>
  );
};

export default Footer;
