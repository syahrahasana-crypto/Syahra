import React from 'react';
import { Briefcase } from 'lucide-react';

const Experience = () => {
  const experiences = [
    {
      title: "Workshop SINERGI FEST",
      company: "Peserta Aktif",
      date: "2025",
      description: "Berperan sebagai peserta aktif, dan memiliki pengalaman membuat projek Web Freelancer."
    },
    {
      title: "Anggota Kresbud",
      company: "OSIS / Organisasi Sekolah",
      date: "2023 - 2024",
      description: "Memiliki proker yang berkaitan dengan Kreasi, Seni, dan Budaya, dan Design. Mengadakan event Pentas Seni di sekolah, menjadi Panitia dalam event OSIS, mengedit feeds, story, reels di platform Instagram."
    },
    {
      title: "Anggota Broadcasting",
      company: "Ekstrakurikuler",
      date: "2023 - 2024",
      description: "Berperan sebagai Anggota, yang memiliki keahlian khusus dibidang photography, dan mempelajari ilmu siaran. Turut berpartisipasi menjadi panitia dokumentasi dalam event di sekolah."
    }
  ];

  return (
    <section id="experience" className="py-20 bg-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white">Experience</h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <div className="relative border-l border-slate-700 ml-4 md:ml-0 md:pl-0 md:grid md:grid-cols-1 md:gap-12">
          {experiences.map((exp, index) => (
            <div key={index} className="mb-8 md:mb-0 relative pl-8 md:pl-0">
              {/* Timeline dot */}
              <div className="absolute -left-1.5 md:left-1/2 md:-ml-1.5 w-3 h-3 bg-blue-500 rounded-full border-4 border-slate-900 z-10"></div>
              
              <div className={`md:flex items-center justify-between ${index % 2 === 0 ? 'md:flex-row-reverse' : ''} w-full`}>
                <div className="hidden md:block w-5/12"></div>
                
                <div className={`w-full md:w-5/12 ${index % 2 === 0 ? 'text-left md:text-left' : 'text-left md:text-right'}`}>
                   <div className="bg-slate-900 p-6 rounded-xl border border-slate-700 hover:border-blue-500/50 transition-colors shadow-lg">
                      <div className={`flex items-center gap-2 mb-2 text-blue-400 ${index % 2 !== 0 ? 'md:justify-end' : ''}`}>
                         <Briefcase size={18} />
                         <span className="text-sm font-semibold">{exp.date}</span>
                      </div>
                      <h3 className="text-xl font-bold text-white mb-1">{exp.title}</h3>
                      <h4 className="text-gray-400 font-medium mb-3">{exp.company}</h4>
                      <p className="text-gray-400 text-sm leading-relaxed">
                        {exp.description}
                      </p>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
