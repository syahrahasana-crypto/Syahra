const API_URL = "https://remotive.com/api/remote-jobs?category=software-dev";

const jobList = document.getElementById("jobList");
const searchInput = document.getElementById("searchInput");
const themeToggle = document.getElementById("themeToggle");
const html = document.documentElement;

let allJobs = [];

// Set mode awal (berdasarkan localStorage atau sistem)
if (
  localStorage.theme === "dark" ||
  (!("theme" in localStorage) &&
    window.matchMedia("(prefers-color-scheme: dark)").matches)
) {
  html.classList.add("dark");
  themeToggle.textContent = "☀ Light";
} else {
  html.classList.remove("dark");
  themeToggle.textContent = "🌙 Dark";
}

// Toggle dark mode
themeToggle.addEventListener("click", () => {
  const isDark = html.classList.toggle("dark");
  localStorage.theme = isDark ? "dark" : "light";
  themeToggle.textContent = isDark ? "☀ Light" : "🌙 Dark";
});

// FETCH JOBS
async function fetchJobs() {
  try {
    const res = await fetch(API_URL);
    const data = await res.json();
    allJobs = data.jobs;
    renderJobs(allJobs);
  } catch (error) {
    jobList.innerHTML = `<p class="text-center text-red-500">Gagal memuat data pekerjaan 😢</p>`;
  }
}

// === RENDER JOBS ===
function renderJobs(jobs) {
  if (!jobs.length) {
    jobList.innerHTML = `<p class="text-center text-gray-600 dark:text-gray-300">Tidak ada hasil ditemukan.</p>`;
    return;
  }

  jobList.innerHTML = jobs
    .map((job) => {
      const date = new Date(job.publication_date).toLocaleDateString("id-ID", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });

      return `
      <div class="bg-white dark:bg-gray-800 dark:text-gray-100 p-4 border dark:border-gray-700 rounded-xl shadow-sm hover:shadow-md transition">
        <div class="flex items-center gap-3 mb-3">
          <img 
            src="${
              job.company_logo_url
                ? `https://images.weserv.nl/?url=${encodeURIComponent(
                    job.company_logo_url
                  )}`
                : `https://ui-avatars.com/api/?name=${encodeURIComponent(
                    job.company_name
                  )}&background=random`
            }" 
            alt="${job.company_name}" 
            class="w-12 h-12 rounded-md object-contain border bg-white dark:bg-gray-700" 
          />
          <div>
            <h2 class="font-semibold text-lg">${job.title}</h2>
            <p class="text-sm text-gray-600 dark:text-gray-400">${
              job.company_name
            }</p>
          </div>
        </div>

        <div class="flex flex-wrap gap-1 mb-3">
          ${job.tags
            .map(
              (tag) => `
            <span class="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 text-xs px-2 py-1 rounded">${tag}</span>
          `
            )
            .join("")}
        </div>

        <p class="text-sm text-gray-700 dark:text-gray-300 mb-3">
          ${job.description.replace(/<[^>]*>/g, "").slice(0, 120)}...
        </p>

        <div class="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
          <span>${job.candidate_required_location}</span>
          <span>📅 ${date}</span>
        </div>

        <div class="mt-2 text-right">
          <a href="${
            job.url
          }" target="_blank" class="text-blue-600 dark:text-blue-400 underline text-sm font-medium hover:text-blue-800">
            Lihat Detail
          </a>
        </div>
      </div>`;
    })
    .join("");
}

// SEARCH FILTER
searchInput.addEventListener("input", (e) => {
  const keyword = e.target.value.toLowerCase();
  const filtered = allJobs.filter(
    (jobs) =>
      jobs.title.toLowerCase().includes(keyword) ||
      jobs.company_name.toLowerCase().includes(keyword) ||
      jobs.tags.join(" ").toLowerCase().includes(keyword)
  );
  renderJobs(filtered);
});

// === INIT ===
fetchJobs();